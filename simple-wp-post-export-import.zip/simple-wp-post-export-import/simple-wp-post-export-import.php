<?php
/*
 * Plugin Name: Simple WP Post Export Import
 * Plugin URI: https://wordpress.org/plugins/simple-wp-post-export-import/
 * Description: Export and import WordPress posts with featured images and categories via a JSON file.
 * Version: 1.0.0
 * Author: DevNajmus
 * Text Domain: simple-wp-post-export-import
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('SWPE_VERSION', '1.0.0');
define('SWPE_PLUGIN_DIR', plugin_dir_path(__FILE__));

// Include all class files
require_once SWPE_PLUGIN_DIR . 'includes/class-ui.php';
require_once SWPE_PLUGIN_DIR . 'includes/class-exporter.php';
require_once SWPE_PLUGIN_DIR . 'includes/class-importer.php';
require_once SWPE_PLUGIN_DIR . 'includes/class-utils.php';

// Initialize the plugin
function swpe_run_plugin() {
    $ui = new swpe_UI();
    $exporter = new swpe_Exporter($ui);
    $importer = new swpe_Importer($ui);
    $utils = new swpe_Utils(); // Standalone but used by others
}
add_action('plugins_loaded', 'swpe_run_plugin');

// Update handler
function swpe_check_for_updates() {
    $current_version = get_option('swpe_version');
    if (!$current_version || version_compare($current_version, SWPE_VERSION, '<')) {
        swpe_run_updates($current_version);
        update_option('swpe_version', SWPE_VERSION);
    }
}
add_action('plugins_loaded', 'swpe_check_for_updates');

// Update function
function swpe_run_updates($old_version) {
    if (!$old_version) {
        // Initial install
        update_option('swpe_version', SWPE_VERSION);
        return;
    }

    // Example update for future versions
    if (version_compare($old_version, '1.1.0', '<')) {
        // Add future update logic here (e.g., database changes)
    }
}