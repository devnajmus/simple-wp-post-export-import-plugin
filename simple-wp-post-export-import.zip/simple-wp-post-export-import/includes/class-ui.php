<?php
class swpe_UI {
    public function __construct() {
        add_action('admin_menu', array($this, 'swpe_add_menu_items'));
    }

    public function swpe_add_menu_items() {
        add_submenu_page(
            'edit.php',
            __('Export Posts', 'simple-wp-post-export'),
            __('Export', 'simple-wp-post-export'),
            'manage_options',
            'swpe-export-posts',
            array($this, 'swpe_export_page')
        );
        add_submenu_page(
            'edit.php',
            __('Import Posts', 'simple-wp-post-export'),
            __('Import', 'simple-wp-post-export'),
            'manage_options',
            'swpe-import-posts',
            array($this, 'swpe_import_page')
        );
    }

    public function swpe_export_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Export Posts', 'simple-wp-post-export'); ?></h1>
            <p><?php _e('Click the button below to export all posts with their featured images and categories.', 'simple-wp-post-export'); ?></p>
            <form method="post">
                <input type="hidden" name="swpe_export_posts" value="1">
                <?php submit_button(__('Export Posts', 'simple-wp-post-export')); ?>
            </form>
        </div>
        <?php
    }

    public function swpe_import_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Import Posts', 'simple-wp-post-export'); ?></h1>
            <p><?php _e('Upload a JSON file to import posts with their featured images and categories.', 'simple-wp-post-export'); ?></p>
            <form method="post" enctype="multipart/form-data">
                <input type="file" name="swpe_import_file" accept=".json" required>
                <input type="hidden" name="swpe_import_posts" value="1">
                <?php submit_button(__('Import Posts', 'simple-wp-post-export')); ?>
            </form>
        </div>
        <?php
    }
}