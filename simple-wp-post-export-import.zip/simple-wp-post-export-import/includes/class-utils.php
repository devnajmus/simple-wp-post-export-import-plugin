<?php
class swpe_Utils {
    public function swpe_import_featured_image($image_url, $post_id) {
        $response = wp_remote_get($image_url, array('timeout' => 10));
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return false;
        }

        $image_data = wp_remote_retrieve_body($response);
        $filename = basename($image_url);
        $upload = wp_upload_bits($filename, null, $image_data);

        if ($upload['error']) {
            return false;
        }

        $file_path = $upload['file'];
        $file_type = wp_check_filetype($filename);

        $attachment = array(
            'post_mime_type' => $file_type['type'],
            'post_title' => sanitize_file_name(pathinfo($filename, PATHINFO_FILENAME)),
            'post_content' => '',
            'post_status' => 'inherit',
        );
        $attachment_id = wp_insert_attachment($attachment, $file_path, $post_id);

        if (is_wp_error($attachment_id)) {
            return false;
        }

        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_path);
        wp_update_attachment_metadata($attachment_id, $attachment_data);

        $result = set_post_thumbnail($post_id, $attachment_id);
        return $result !== false;
    }

    public function swpe_get_or_create_category($category_name) {
        $category_id = term_exists($category_name, 'category');
        if ($category_id) {
            return is_array($category_id) ? $category_id['term_id'] : $category_id;
        }

        $category_id = wp_insert_category(array(
            'cat_name' => $category_name,
            'category_description' => '',
            'category_nicename' => sanitize_title($category_name),
            'taxonomy' => 'category',
        ));

        return is_wp_error($category_id) ? false : $category_id;
    }

    public function swpe_get_upload_error_message($code) {
        switch ($code) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return __('File is too large.', 'simple-wp-post-export');
            case UPLOAD_ERR_PARTIAL:
                return __('File was only partially uploaded.', 'simple-wp-post-export');
            case UPLOAD_ERR_NO_FILE:
                return __('No file was uploaded.', 'simple-wp-post-export');
            case UPLOAD_ERR_NO_TMP_DIR:
                return __('Missing temporary folder.', 'simple-wp-post-export');
            case UPLOAD_ERR_CANT_WRITE:
                return __('Failed to write file to disk.', 'simple-wp-post-export');
            case UPLOAD_ERR_EXTENSION:
                return __('A PHP extension stopped the file upload.', 'simple-wp-post-export');
            default:
                return __('Unknown upload error.', 'simple-wp-post-export');
        }
    }
}