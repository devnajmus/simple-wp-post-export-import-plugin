<?php
class swpe_Importer {
    private $utils;

    public function __construct($ui) {
        $this->utils = new swpe_Utils();
        add_action('admin_init', array($this, 'swpe_handle_import'));
    }

    public function swpe_handle_import() {
        if (isset($_POST['swpe_import_posts']) && current_user_can('manage_options') && isset($_FILES['swpe_import_file'])) {
            $file = $_FILES['swpe_import_file'];

            if ($file['error'] !== UPLOAD_ERR_OK) {
                echo '<div class="error"><p>' . sprintf(__('File upload failed: %s', 'simple-wp-post-export'), $this->utils->swpe_get_upload_error_message($file['error'])) . '</p></div>';
                return;
            }

            $file_content = file_get_contents($file['tmp_name']);
            $posts = json_decode($file_content, true);

            if (!is_array($posts) || empty($posts)) {
                echo '<div class="error"><p>' . __('Invalid or empty JSON file!', 'simple-wp-post-export') . '</p></div>';
                return;
            }

            $imported_count = 0;
            foreach ($posts as $post_data) {
                $post = array(
                    'post_title' => sanitize_text_field($post_data['title']),
                    'post_content' => wp_kses_post($post_data['content']),
                    'post_excerpt' => sanitize_text_field($post_data['excerpt']),
                    'post_status' => sanitize_text_field($post_data['status']),
                    'post_date' => $post_data['date'],
                    'post_type' => 'post',
                    'post_author' => get_current_user_id(),
                );
                $post_id = wp_insert_post($post, true);

                if (is_wp_error($post_id)) {
                    echo '<div class="error"><p>' . sprintf(__('Failed to import post: %s', 'simple-wp-post-export'), $post_data['title']) . '</p></div>';
                    continue;
                }

                if (!empty($post_data['featured_image'])) {
                    $image_success = $this->utils->swpe_import_featured_image($post_data['featured_image'], $post_id);
                    if (!$image_success) {
                        echo '<div class="notice notice-warning"><p>' . sprintf(__('Imported post "%s" but failed to set featured image.', 'simple-wp-post-export'), $post_data['title']) . '</p></div>';
                    }
                }

                if (!empty($post_data['categories']) && is_array($post_data['categories'])) {
                    $category_ids = array();
                    foreach ($post_data['categories'] as $category_name) {
                        $category_id = $this->utils->swpe_get_or_create_category($category_name);
                        if ($category_id) {
                            $category_ids[] = $category_id;
                        }
                    }
                    if (!empty($category_ids)) {
                        wp_set_post_categories($post_id, $category_ids);
                    }
                }

                $imported_count++;
            }

            echo '<div class="updated"><p>' . sprintf(__('Successfully imported %d post(s)!', 'simple-wp-post-export'), $imported_count) . '</p></div>';
        }
    }
}