<?php
class swpe_Exporter {
    public function __construct($ui) {
        add_action('admin_init', array($this, 'swpe_handle_export'));
    }

    public function swpe_handle_export() {
        if (isset($_POST['swpe_export_posts']) && current_user_can('manage_options')) {
            $posts = get_posts(array(
                'post_type' => 'post',
                'post_status' => 'any',
                'numberposts' => -1
            ));

            if (empty($posts)) {
                wp_die(__('No posts found to export.', 'simple-wp-post-export'));
            }

            $export_data = array();
            foreach ($posts as $post) {
                $thumbnail_id = get_post_thumbnail_id($post->ID);
                $thumbnail_url = $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : '';
                $categories = wp_get_post_categories($post->ID, array('fields' => 'names'));

                $export_data[] = array(
                    'title' => $post->post_title,
                    'content' => $post->post_content,
                    'excerpt' => $post->post_excerpt,
                    'status' => $post->post_status,
                    'date' => $post->post_date,
                    'author' => get_the_author_meta('display_name', $post->post_author),
                    'featured_image' => $thumbnail_url,
                    'categories' => $categories,
                );
            }

            $filename = 'swpe-posts-export-' . date('Y-m-d') . '.json';
            header('Content-Type: application/json');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            echo json_encode($export_data, JSON_PRETTY_PRINT);
            exit;
        }
    }
}